import React from "react";
import { connect } from "react-redux";
import { MenuItem, Input, InputLabel, FormControl } from "@material-ui/core/";
import { jsonListOptions } from "./search-list.json";


class SearchComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          selectedVal: "",
        };
        this.handleChangeDivision = this.handleChangeDivision.bind(this);
    }
    renderDivisionOptions() {
        return this.props.selectData.map((dt, i) => {
          return (
            <MenuItem key={i} value={dt.value}>
              {dt.label}
            </MenuItem>
          );
        });
    }
    
    handleChangeDivision(event) {
        let data = {};
        data = event.target.value;
        this.setState({ selectedVal: data });
        // this.props.dispatch(selectBoxOptions(data));
    }

    render() {
        return (
            <FormControl>
                <InputLabel htmlFor="searchInput">Enter Name</InputLabel>
                <Input
                    value={this.state.selectedVal}
                    onChange={this.handleChangeDivision.bind(this)}
                    name="searchInput"
                    >
                </Input>
            </FormControl>  
        )
    }
}

export default connect()(SearchComponent);

