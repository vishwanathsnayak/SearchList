import React from "react";
import { connect } from "react-redux";
import compose from 'recompose/compose';
import TableHeaderSorting from "./TableHeaderSorting.jsx";

import {
    Table,
    TableBody,
    TableCell,
    TableRow,
    TablePagination,
    Paper,
    withStyles
  } from '@material-ui/core/';
  
  const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
  });

  class TableComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            page: 0,
            rowsPerPage: 10,
            order: 'asc',
            orderByCol: 'name'
        }
    }
    
    componentDidMount() {
        console.log("tblcomponent componentDidMount:")
    }
    componentWillReceiveProps(newProps) {
        console.log("tblcomponent componentWillReceiveProps = ",newProps)
        
    }

    handleChangePage = (event, page) => {
        this.setState({ page });
    }

    handleChangeRowsPerPage = event => {
        this.setState({ rowsPerPage: event.target.value });
    }
    
    desc = (a, b, orderByCol) => {
        if (b[orderByCol] < a[orderByCol]) {
            return -1;
        }
        if (b[orderByCol] > a[orderByCol]) {
            return 1;
        }
        return 0;
    }
    
    stableSort = (array, cmp) => {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = cmp(a[0], b[0]);
            if (order !== 0) return order;
            return a[1] - b[1];
        });
        return stabilizedThis.map(el => el[0]);
    }
    
    getSorting = (order, orderByCol) => {
        return order === 'desc' ? (a, b) => this.desc(a, b, orderByCol) : (a, b) => -this.desc(a, b, orderByCol);
    }

    handleRequestSort = (event, property) => {
        const orderByCol = property;
        let order = 'desc';
    
        if (this.state.orderByCol === property && this.state.order === 'desc') {
          order = 'asc';
        }
        this.setState({ order, orderByCol });
    };

    render() {
        const { classes } = this.props;
        let resultList="", { gitRepo_Results } = this.props;
        const { rowsPerPage, page, order, orderByCol } = this.state;
        const emptyRows = rowsPerPage - Math.min(rowsPerPage, gitRepo_Results.length - page * rowsPerPage);
        if(gitRepo_Results) {
            resultList = this.stableSort(gitRepo_Results, this.getSorting(order, orderByCol)).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((item, index) => {
                /*sorting with lodash orderBy
                resultList = orderBy(gitRepo_Results, orderByCol, order).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((item, index) => {
                */
                return (
                    <TableRow key={index} data={item} tabIndex={-1}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell className="alignRight">{item.starCount}</TableCell>
                        <TableCell className="alignRight">{item.forksCount}</TableCell>
                    </TableRow>
                );
            })
        }

        const MuiTable = () => (
            <Paper className={classes.root}>
                <Table className={classes.table}>
                    <TableHeaderSorting
                        order={order}
                        orderByCol={orderByCol}
                        onRequestSort={this.handleRequestSort}
                    />
                    <TableBody>
                        {resultList}
                        {emptyRows > 0 && (
                            <TableRow style={{ height: 49 * emptyRows }}>
                                <TableCell colSpan={3} />
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
                <TablePagination
                    component="div"
                    count={gitRepo_Results.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    backIconButtonProps={{
                        'aria-label': 'Previous Page',
                    }}
                    nextIconButtonProps={{
                        'aria-label': 'Next Page',
                    }}
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
            </Paper>
        )
        return (
            <div>
               <MuiTable />
            </div>
        )
      }
}

const mapStateToProps = state => ({
    selectedValue: state.reducer.selectedValue,
    gitRepo_Results: state.reducer.gitRepo_Results
});

export default compose(
    withStyles(styles, { name: 'TableComponent' }),
    connect(mapStateToProps, null)
  )(TableComponent);

